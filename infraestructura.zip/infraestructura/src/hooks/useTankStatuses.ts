// src/hooks/useTankStatuses.ts
import { useEffect, useState } from 'react'
import { TankStatusOut } from '@/api/status'

export default function useTankStatuses(
  nodes: Array<{ type: string; asset_id?: number; level?: number; tank_status?: string; tank_color_hex?: string }> // Los nodos ya tienen esta información
) {
  const [data, setData] = useState<TankStatusOut[] | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      // Simulando la obtención de los estados de los tanques directamente desde los nodos
      const tankStatuses = nodes
        .filter((node) => node.type === 'tank')
        .map((node) => ({
          tank_id: node.asset_id!,
          status: node.tank_status || 'offline', // Asumimos 'offline' si no hay estado
          color_hex: node.tank_color_hex || '#000000', // Asumimos negro si no hay color
        }));

      setData(tankStatuses);
      setError(null);
    } catch (e: any) {
      setError(String(e?.message || e));
    }
  }, [nodes]); // Depende de los nodos

  return { data, error }
}
