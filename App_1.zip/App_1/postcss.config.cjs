// Tailwind v4: no hace falta autoprefixer
module.exports = {
  plugins: {
    "@tailwindcss/postcss": {}
  }
};
