// src/components/TankLevelChart.tsx
import React, { useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ReferenceArea,
  Legend,
  Brush,
} from "recharts";

type TankTs = { timestamps?: string[]; level_percent?: Array<number | string | null> };

type Thresholds = {
  low_pct?: number | null;       // L
  low_low_pct?: number | null;   // LL
  high_pct?: number | null;      // H
  high_high_pct?: number | null; // HH
};

type Props = {
  ts: TankTs | null;
  title?: string;
  thresholds?: Thresholds;
  tz?: string;       // default "America/Argentina/Buenos_Aires"
  height?: number;   // default 260
  showLegend?: boolean; // default true
  showBrushIf?: number; // default 120 (si hay más de N puntos, muestra brush)
};

function toMs(x: string): number {
  // Intenta parsear ISO; si falla, que el Date haga lo suyo
  const d = new Date(x);
  return d.getTime();
}

function fmtTime(ms: number, tz = "America/Argentina/Buenos_Aires") {
  try {
    return new Intl.DateTimeFormat("es-AR", {
      timeZone: tz,
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "2-digit",
    }).format(ms);
  } catch {
    return new Date(ms).toLocaleString();
  }
}

export function TankLevelChart({
  ts,
  title = "Nivel del tanque (24h)",
  thresholds,
  tz = "America/Argentina/Buenos_Aires",
  height = 260,
  showLegend = true,
  showBrushIf = 120,
}: Props) {
  // Normalizamos series a { t: ms, nivel: number|null }
  const series = useMemo(() => {
    const t = ts?.timestamps ?? [];
    const lv = ts?.level_percent ?? [];
    const rows: { t: number; nivel: number | null }[] = [];
    const N = Math.min(t.length, lv.length);

    for (let i = 0; i < N; i++) {
      const raw = lv[i];
      const n = raw === null || raw === undefined ? NaN : Number(raw);
      const nivel = Number.isFinite(n) ? n : null;
      const ms = toMs(t[i] ?? "");
      if (!Number.isFinite(ms)) continue; // timestamp inválido
      rows.push({ t: ms, nivel });
    }
    // ordena por tiempo por si vienen desordenados
    rows.sort((a, b) => a.t - b.t);
    return rows;
  }, [ts]);

  const hasData = series.length > 0 && series.some((d) => d.nivel != null);

  // Dominio Y dinámico (respetando 0..100 por defecto)
  const yMin = useMemo(() => {
    const vals = series.map((d) => (d.nivel == null ? Infinity : d.nivel));
    const m = Math.min(...vals);
    return Number.isFinite(m) ? Math.floor(Math.min(0, m)) : 0;
  }, [series]);

  const yMax = useMemo(() => {
    const vals = series.map((d) => (d.nivel == null ? -Infinity : d.nivel));
    const m = Math.max(...vals);
    return Number.isFinite(m) ? Math.ceil(Math.max(100, m)) : 100;
  }, [series]);

  const L  = thresholds?.low_pct ?? null;
  const LL = thresholds?.low_low_pct ?? null;
  const H  = thresholds?.high_pct ?? null;
  const HH = thresholds?.high_high_pct ?? null;

  // Id de gradiente único por instancia
  const gradId = useMemo(() => `gradTank_${Math.random().toString(36).slice(2)}`, []);

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm text-gray-500">{title}</CardTitle>
      </CardHeader>

      <CardContent className="h-64" style={{ height }}>
        {!hasData ? (
          <div className="h-full grid place-items-center text-sm text-gray-500">Sin datos</div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={series} margin={{ top: 8, right: 16, left: 8, bottom: 0 }}>
              <defs>
                <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="currentColor" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="currentColor" stopOpacity={0.05} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" opacity={0.3} />

              <XAxis
                dataKey="t"
                type="number"
                domain={["dataMin", "dataMax"]}
                tickFormatter={(v) => fmtTime(v as number, tz)}
                tickMargin={8}
                minTickGap={36}
              />

              <YAxis
                domain={[yMin, yMax]}
                tickFormatter={(v) => `${v}%`}
                width={40}
              />

              <Tooltip
                cursor={{ strokeDasharray: "3 3" }}
                content={({ active, payload }) => {
                  if (!active || !payload || !payload.length) return null;
                  const p = payload[0].payload as { t: number; nivel: number | null };
                  const nivel = p.nivel == null ? "--" : `${p.nivel.toFixed(1)}%`;
                  return (
                    <div className="rounded-lg border bg-background px-3 py-2 shadow-sm">
                      <div className="text-xs text-muted-foreground">{fmtTime(p.t, tz)}</div>
                      <div className="text-sm font-medium">Nivel: {nivel}</div>
                    </div>
                  );
                }}
              />

              {/* Bandas: crítico abajo/arriba y banda OK entre L y H */}
              {typeof LL === "number" && (
                <ReferenceArea y1={0} y2={LL} fill="var(--destructive)" fillOpacity={0.08} />
              )}
              {typeof HH === "number" && (
                <ReferenceArea y1={HH} y2={Math.max(100, yMax)} fill="var(--destructive)" fillOpacity={0.08} />
              )}
              {typeof L === "number" && typeof H === "number" && H > L && (
                <ReferenceArea y1={L} y2={H} fill="var(--primary)" fillOpacity={0.06} />
              )}

              {/* Líneas de umbral */}
              {typeof LL === "number" && (
                <ReferenceLine
                  y={LL}
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  opacity={0.6}
                  label={{ value: `LL ${LL}%`, position: "insideTopRight", fontSize: 10 }}
                />
              )}
              {typeof L === "number" && (
                <ReferenceLine
                  y={L}
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  opacity={0.5}
                  label={{ value: `L ${L}%`, position: "insideTopRight", fontSize: 10 }}
                />
              )}
              {typeof H === "number" && (
                <ReferenceLine
                  y={H}
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  opacity={0.5}
                  label={{ value: `H ${H}%`, position: "insideTopRight", fontSize: 10 }}
                />
              )}
              {typeof HH === "number" && (
                <ReferenceLine
                  y={HH}
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  opacity={0.6}
                  label={{ value: `HH ${HH}%`, position: "insideTopRight", fontSize: 10 }}
                />
              )}

              <Area
                type="monotone"
                dataKey="nivel"
                stroke="currentColor"
                strokeWidth={2}
                fill={`url(#${gradId})`}
                connectNulls
                dot={false}
                isAnimationActive={false}
              />

              {showLegend && <Legend verticalAlign="top" height={24} />}

              {series.length > showBrushIf && (
                <Brush
                  dataKey="t"
                  height={22}
                  stroke="currentColor"
                  travellerWidth={8}
                  tickFormatter={(v) => fmtTime(v as number, tz)}
                />
              )}
            </AreaChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}

export default TankLevelChart;
