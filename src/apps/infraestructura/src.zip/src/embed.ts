// src/embed.ts
export type InfraCtx = {
  orgId: number;
  apiBase: string;
  apiKey?: string;
  authInQuery?: boolean;
  wsBase?: string;
};

declare global {
  interface Window {
    __APP_CTX__?: Partial<InfraCtx>;
    __INFRA_CTX__?: Partial<InfraCtx>;
    __EMBED_HOST_ORIGIN__?: string;
  }
}

let heightInstalled = false;
let ctxInstalled = false;

// --- mini bus de “ctx listo” ---
type Cb = (ctx: InfraCtx) => void;
const listeners: Cb[] = [];

function currentCtx(): Partial<InfraCtx> {
  const w = window as any;
  return w.__INFRA_CTX__ || w.__APP_CTX__ || {};
}

function normalizeBase(b?: string) {
  const origin = typeof window !== "undefined" ? window.location.origin : "http://localhost";
  let base = String(b || "").trim();
  if (!base) base = origin;
  // si no es absoluta, la resuelvo contra el origin
  try { base = new URL(base, origin).toString(); } catch { base = origin; }
  return base.replace(/\/+$/,"");
}

function mergeCtx(patch?: Partial<InfraCtx>) {
  if (!patch) return;
  const w = window as any;
  const next = { ...(currentCtx() || {}), ...patch };
  // Normalizo apiBase si viene
  if (next.apiBase) next.apiBase = normalizeBase(next.apiBase);
  w.__APP_CTX__   = next;
  w.__INFRA_CTX__ = next;
  // notificar si está “listo”
  if (next.orgId && next.apiBase) {
    const full = next as InfraCtx;
    while (listeners.length) {
      try { listeners.shift()?.(full); } catch {}
    }
  }
}

export function onCtx(fn: Cb) {
  const c = currentCtx();
  if (c && c.orgId && c.apiBase) { fn(c as InfraCtx); return () => {}; }
  listeners.push(fn);
  return () => {
    const i = listeners.indexOf(fn);
    if (i >= 0) listeners.splice(i, 1);
  };
}

export function waitForCtx(opts: { timeout?: number; needApiBase?: boolean } = {}) {
  const { timeout = 3000, needApiBase = true } = opts;
  return new Promise<InfraCtx>((resolve, reject) => {
    let done = false;

    const tryResolve = () => {
      if (done) return true;
      const c = currentCtx();
      const ok = c && c.orgId && (!needApiBase || !!c.apiBase);
      if (ok) { done = true; resolve(c as InfraCtx); return true; }
      return false;
    };

    if (tryResolve()) return;

    const unsub = onCtx((ctx) => {
      if (done) return;
      done = true;
      unsub();
      resolve(ctx);
    });

    const t = setTimeout(() => {
      if (done) return;
      done = true;
      unsub();
      reject(new Error("ctx timeout (no llegó EMBED_INIT)"));
    }, timeout);

    const tick = () => {
      if (done) return;
      if (tryResolve()) clearTimeout(t);
      else requestAnimationFrame(tick);
    };
    tick();
  });
}

export function getCtx(): Partial<InfraCtx> {
  return currentCtx();
}

// ---- auto altura (EMBED_HEIGHT) ----
function setupAutoHeight() {
  if (heightInstalled) return;
  heightInstalled = true;

  const isEmbedded = (() => { try { return window.top !== window.self; } catch { return true; } })();
  if (!isEmbedded) return;

  const measure = () => Math.max(
    document.documentElement.scrollHeight,
    document.body?.scrollHeight || 0,
    document.documentElement.offsetHeight,
    document.body?.offsetHeight || 0
  );

  const send = () => {
    const height = measure();
    const host = (window as any).__EMBED_HOST_ORIGIN__ || "*";
    parent.postMessage({ type: "EMBED_HEIGHT", height }, host);
  };

  window.addEventListener("message", (e: MessageEvent) => {
    if (e.data?.type === "EMBED_INIT") {
      (window as any).__EMBED_HOST_ORIGIN__ = e.origin || "*";
      send();
    }
  });

  const ro = new ResizeObserver(send);
  ro.observe(document.documentElement);

  const mo = new MutationObserver(send);
  mo.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });

  window.addEventListener("load", send);
  window.addEventListener("resize", send);
  const id = window.setInterval(send, 1000);
  window.addEventListener("beforeunload", () => clearInterval(id));
}

// ---- init (query + EMBED_INIT) ----
export function initEmbed() {
  if (ctxInstalled) return;
  ctxInstalled = true;

  // 1) Fallback por query (solo org y api opcional; NUNCA apiKey en query)
  try {
    const q = new URLSearchParams(location.search);
    const org = Number(q.get("org"));
    const api = q.get("api") || q.get("apiBase") || q.get("api_base");
    const initial: Partial<InfraCtx> = {};
    if (Number.isFinite(org) && org > 0) initial.orgId = org;
    if (api) initial.apiBase = normalizeBase(api);
    if (initial.orgId || initial.apiBase) mergeCtx(initial);
  } catch {}

  // 2) Handshake desde el shell
  window.addEventListener("message", (e: MessageEvent) => {
    const d: any = e.data;
    if (!d || d.type !== "EMBED_INIT") return;
    (window as any).__EMBED_HOST_ORIGIN__ = e.origin || "*";
    if (d.ctx) {
      const incoming: Partial<InfraCtx> = { ...d.ctx };
      mergeCtx(incoming);
      try { (e.source as WindowProxy)?.postMessage({ type: "EMBED_READY" }, e.origin || "*"); } catch {}
    }
  });

  // 3) Altura automática
  setupAutoHeight();
}

// ---- helpers opcionales para App.tsx ----
export function ensureInfraBase(httpBase: string) {
  const base = String(httpBase || "").replace(/\/+$/,"");
  return base.endsWith("/infra") ? base : `${base}/infra`;
}
export function buildInfraHeaders(ctx: Partial<InfraCtx>): HeadersInit {
  const h: Record<string,string> = { Accept: "application/json" };
  if (ctx.apiKey) { h["X-API-Key"] = ctx.apiKey; h["Authorization"] = `Bearer ${ctx.apiKey}`; }
  if (ctx.orgId)  h["X-Org-Id"] = String(ctx.orgId);
  return h;
}
