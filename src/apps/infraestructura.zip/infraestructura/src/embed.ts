// src/embed.ts
// EMBED auto-contenido: contexto, EMBED_INIT, auto-height y helpers de API.

export type AppCtx = {
  orgId: number;
  apiBase: string;
  apiKey?: string;
  authInQuery?: boolean;
  wsBase?: string;
};

type CtxListener = (ctx: AppCtx) => void;

const DEBUG = (localStorage.getItem("embed:debug") ?? "0") !== "0";
const dlog  = (...a: any[]) => { if (DEBUG) console.log("[EMBED]", ...a); };
const dwarn = (...a: any[]) => { if (DEBUG) console.warn("[EMBED]", ...a); };

// ——— Marca <html>.is-embedded ———
(function markEmbeddedIIFE() {
  try { if (window.top !== window.self) document.documentElement.classList.add("is-embedded"); }
  catch { document.documentElement.classList.add("is-embedded"); }
})();

// ——— Contexto ———
let listeners = new Set<CtxListener>();

function emitCtx() {
  const snap = getCtx();
  try { window.dispatchEvent(new CustomEvent("ctx:changed", { detail: snap })); } catch {}
  for (const fn of listeners) { try { fn(snap); } catch (e) { dwarn("ctx listener error", e); } }
}

export function onCtxChange(fn: CtxListener) { listeners.add(fn); return () => listeners.delete(fn); }
// ALIAS para compatibilidad con App.tsx
export const onCtx = onCtxChange;

function deriveInitialCtx(): AppCtx {
  const q = new URLSearchParams(location.search);
  const env: any = (import.meta as any)?.env ?? {};
  const orgFromQuery = Number(q.get("org"));
  const orgFromEnv   = Number(env.VITE_ORG_ID);
  const orgId = [orgFromQuery, orgFromEnv].find((v) => Number.isFinite(v) && v! > 0) as number | undefined;

  const apiBase = String(env.VITE_API_URL || "");
  const apiKey  = (env.VITE_API_KEY || undefined) as string | undefined;
  const authInQuery = env.VITE_AUTH_IN_QUERY === "1";
  const wsBase  = (env.VITE_WS_URL || undefined) as string | undefined;

  if (!orgId) dwarn("orgId no definido (vendrá por EMBED_INIT o ?org= / VITE_ORG_ID).");
  if (!apiBase) dwarn("apiBase vacío (definí VITE_API_URL o enviá EMBED_INIT).");

  return { orgId: Number(orgId || 0), apiBase, apiKey, authInQuery, wsBase };
}

let ctx: AppCtx = deriveInitialCtx();

function reflectCtxToHtml() {
  const html = document.documentElement;
  html.setAttribute("data-org-id", String(ctx.orgId ?? ""));
  if (ctx.apiBase) html.setAttribute("data-api-base", ctx.apiBase);
}

export function getCtx(): AppCtx { return ctx; }
export function setCtx(next: Partial<AppCtx>) {
  const nextOrg = Number(next.orgId ?? ctx.orgId);
  ctx = { ...ctx, ...next, orgId: Number.isFinite(nextOrg) ? nextOrg : 0 };
  reflectCtxToHtml(); dlog("ctx updated", ctx); emitCtx();
}
export function forceOrg(id: number) { setCtx({ orgId: Number(id) }); }

// Recibe EMBED_INIT { type: 'EMBED_INIT', ctx: AppCtx }
window.addEventListener("message", (e: MessageEvent) => {
  const data: any = e.data;
  if (!data || typeof data !== "object") return;
  if (data.type !== "EMBED_INIT") return;
  if (data.ctx && typeof data.ctx === "object") setCtx(data.ctx);
  else dwarn("EMBED_INIT sin ctx");
});

// ——— Auto-height iframe ———
export function postHeight(h: number) {
  try {
    const hh = Math.max(0, Math.ceil(Number(h) || 0));
    if (!hh) return;
    window.parent?.postMessage({ type: "EMBED_HEIGHT", height: hh }, "*");
    dlog("height ->", hh);
  } catch (e) { dwarn("postHeight error", e); }
}

let ro: ResizeObserver | null = null;
let lastH = 0; let rafId: number | null = null;

function computeDocHeight(): number {
  const de = document.documentElement, b = document.body;
  return Math.max(
    de?.scrollHeight || 0, de?.offsetHeight || 0, de?.clientHeight || 0,
    b?.scrollHeight  || 0, b?.offsetHeight  || 0, b?.clientHeight  || 0
  );
}
function scheduleHeightPost() {
  if (rafId != null) return;
  rafId = requestAnimationFrame(() => {
    rafId = null;
    const h = computeDocHeight();
    if (h !== lastH) { lastH = h; postHeight(h); }
  });
}
export function startAutoHeight() {
  try {
    scheduleHeightPost();
    if ("ResizeObserver" in window) {
      ro = new ResizeObserver(() => scheduleHeightPost());
      ro.observe(document.documentElement); if (document.body) ro.observe(document.body);
    } else {
      // @ts-ignore
      (startAutoHeight as any)._interval = window.setInterval(scheduleHeightPost, 500);
    }
    new MutationObserver(() => scheduleHeightPost())
      .observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
    window.addEventListener("load", scheduleHeightPost, { once: true });
    window.addEventListener("pageshow", scheduleHeightPost);
  } catch (e) { dwarn("startAutoHeight error", e); }
}
export function stopAutoHeight() {
  try {
    if (ro) { ro.disconnect(); ro = null; }
    // @ts-ignore
    const iv = (startAutoHeight as any)._interval as number | undefined;
    if (iv) clearInterval(iv);
    lastH = 0;
  } catch {}
}
// Auto-height por defecto si ya estamos embebidos
if (document.documentElement.classList.contains("is-embedded")) {
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", () => startAutoHeight(), { once: true });
  else startAutoHeight();
}
// @ts-ignore
(window as any).__EMBED = { getCtx, setCtx, forceOrg, startAutoHeight, stopAutoHeight };

// ——— Helpers API ———
export type ApiHeaders = Record<string, string>;

function normalizeBase(raw: string): string {
  const s = String(raw || "").trim();
  if (!s) return "";
  try {
    const u = new URL(s);
    const path = u.pathname.replace(/\/+$/, "");
    return path && path !== "/" ? `${u.origin}${path}` : u.origin;
  } catch {
    try {
      const u2 = new URL(s.startsWith("//") ? `${location.protocol}${s}` : `${location.protocol}//${s}`);
      const path = u2.pathname.replace(/\/+$/, "");
      return path && path !== "/" ? `${u2.origin}${path}` : u2.origin;
    } catch { return ""; }
  }
}

/** Asegura y guarda la base del backend. */
export function ensureInfraBase(maybeBase?: string): string {
  let base = (maybeBase ?? getCtx().apiBase ?? "").trim();
  const env: any = (import.meta as any)?.env ?? {};
  if (!base && env.VITE_API_URL) base = String(env.VITE_API_URL);
  const norm = normalizeBase(base);
  if (!norm) { dwarn("ensureInfraBase: apiBase vacío o inválido."); return ""; }
  if (norm !== getCtx().apiBase) setCtx({ apiBase: norm });
  return norm;
}

/** apiBase sin slash final (o "") */
function apiBase(): string { return normalizeBase(getCtx().apiBase || ""); }

/** Concatena base + path (path con o sin "/"). Si no hay base, devuelve el path. */
export function api(path: string): string {
  const base = apiBase();
  const p = String(path || "");
  const normalized = p.startsWith("/") ? p : `/${p}`;
  if (!base) { console.warn("[EMBED] apiBase vacío; devolviendo path sin base:", normalized); return normalized; }
  return `${base}${normalized}`;
}

/** Agrega ?api_key=... si authInQuery está activo. */
export function withAuth(url: string): string {
  const c = getCtx();
  if (!c.authInQuery || !c.apiKey) return url;
  try {
    const u = new URL(url, location.origin);
    if (!u.searchParams.get("api_key")) u.searchParams.set("api_key", c.apiKey);
    return u.toString();
  } catch { return url; }
}

/**
 * Headers estándar para backend Infraestructura.
 * Compat: si le pasás un AppCtx, extrae orgId/apiKey y NO los usa como nombres de encabezado.
 */
export function buildInfraHeaders(extraOrCtx: Record<string, any> = {}): ApiHeaders {
  const c = getCtx();
  const isCtxLike = "orgId" in extraOrCtx || "apiBase" in extraOrCtx || "apiKey" in extraOrCtx;

  const orgId = Number.isFinite(extraOrCtx.orgId) ? Number(extraOrCtx.orgId) : c.orgId;
  const apiKey = (isCtxLike && extraOrCtx.apiKey) ? String(extraOrCtx.apiKey) : c.apiKey;

  const h: ApiHeaders = {
    "content-type": "application/json",
    "x-org-id": String(Number.isFinite(orgId) ? orgId : 0),
  };

  if (apiKey) h["x-api-key"] = apiKey;

  // mezclar headers extra que tengan pinta de header (letras/dígitos/guiones)
  for (const [k, v] of Object.entries(extraOrCtx || {})) {
    if (isCtxLike && (k === "orgId" || k === "apiKey" || k === "apiBase" || k === "authInQuery" || k === "wsBase")) continue;
    if (/^[A-Za-z0-9-]+$/.test(k)) h[k.toLowerCase()] = String(v);
  }
  return h;
}

// ——— initEmbed ———
export type InitEmbedOptions = {
  ctx?: Partial<AppCtx>;
  markEmbedded?: boolean;
  autoHeight?: boolean;
  ensureBase?: string | boolean;
};

export function initEmbed(opts: InitEmbedOptions = {}): AppCtx {
  if (opts.markEmbedded) { try { document.documentElement.classList.add("is-embedded"); } catch {} }
  if (opts.ensureBase === true) ensureInfraBase();
  else if (typeof opts.ensureBase === "string") ensureInfraBase(opts.ensureBase);
  else ensureInfraBase(getCtx().apiBase);

  if (opts.ctx) setCtx(opts.ctx);

  const wantsAuto = opts.autoHeight !== false;
  if (wantsAuto && document.documentElement.classList.contains("is-embedded")) startAutoHeight();

  return getCtx();
}
